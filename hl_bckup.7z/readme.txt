================================================
These are the backup hl.exe.
Please do not delete this archive.

*hl_metahook - exe file with metahook injector which HS needs
*hl_orig - exe without metahook injector for fixing problems
================================================

If your video settings changed and you are not
able to run Hellstrike here's what to do:

1. Rename the 'hl.exe' to something like 'hl_backup.exe'.
2. Copy 'hl_orig.exe' from the archive into the HellStrike folder.
3. Rename 'hl_orig.exe' to 'hl.exe'.
4. Run HellStrike by double-clicking 'hellstrike.exe'.
5. Change your video settings to OpenGL and proper screen resolution.
6. Click OK and exit HellStrike.
7. The client may crash at this point but that's normal.
8. Delete or rename 'hl.exe' back to 'hl_orig.exe'.
9. Rename 'hl_backup.exe' back to 'hl.exe'.
10. Now you can play the game.

Note: You will not be able to open the HUD if you continue to use
hl.exe without the metahook injector.